﻿using System;

namespace HomeTestPost.Data
{
    public class PostDbContext
    {

    }
}
