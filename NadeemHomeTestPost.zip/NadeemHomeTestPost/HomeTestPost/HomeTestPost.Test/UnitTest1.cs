using HomeTestPost.Model;
using System;
using Xunit;

namespace HomeTestPost.Test
{
    public class UnitTest1
    {
        [Fact]
        public void SavePost()
        {
            Post position = new Post()
            {
                Title = "New post",
                Body = "This is post body",
                UserId = 1,
                SortBy = "New"
            };
            var actualOutput = position;
            var expectedOutput = position;
            Assert.Equal(expectedOutput, actualOutput);

        }
    }
}
