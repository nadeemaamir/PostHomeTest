﻿using HomeTestPost.Model;
using HomeTestPost.Service.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HomeTestPost.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly IPostService _postService;
        public PostController(IPostService postService)
        {
            _postService = postService;
        }

        [HttpGet]
        [Route("getallposts")]
        public async Task<IActionResult> GetAllPost()
        {
            var posts = await _postService.GetAllPost();
            return Ok(posts);
        }

        [HttpGet]
        [Route("getallpoststest")]
        public IActionResult GetAllPostTest()
        {
            var posts =  _postService.GetAllPost();
            return Ok(posts);
        }


        [HttpGet]
        [Route("getallposts/{SortBy}")]
        public async Task<IActionResult> GetAllPost(string SortBy)
        {
            var posts = await _postService.GetAllPostSortBy(SortBy);
            return Ok(posts);
        }
        [HttpPost]
        [Route("createpost")]
        public async Task<IActionResult> CreatePosts(Post post)
        {
           Post _post = await _postService.CreatePost(post);
            return Ok(_post);
        }
        [HttpPost]
        [Route("updatepost")]
        public async Task<IActionResult> UpdatePost(Post post)
        {
            Post _post = await _postService.UpdatePost(post);
            return Ok(_post);
        }
        [HttpDelete]
        [Route("deletepost")]
        public IActionResult DeletePost(int Id)
        {
            _postService.DeletePost(Id);
            return Ok();
        }
        [HttpPost]
        [Route("getpostbyid")]
        public async Task<IActionResult> GetPostById(int Id)
        {
            Post _post = await _postService.GetPostById(Id);
            return Ok(_post);
        }

    }
}
