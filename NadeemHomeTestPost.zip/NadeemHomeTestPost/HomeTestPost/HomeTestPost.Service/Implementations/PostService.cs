﻿using HomeTestPost.Model;
using HomeTestPost.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HomeTestPost.Service.Implementations
{
    public class PostService : IPostService
    {
        private readonly List<Post> _posts;
      

        public PostService()
        {
            _posts = new List<Post>()
            {
                new Post { Id = 1, UserId = 1, Title = "sunt aut facere repellat provident occaecati excepturi optio reprehenderit", Body = "quia et suscipit suscipit recusandae consequuntur expedita et cum reprehenderit molestiae ut ut quas totam nostrum rerum est autem sunt rem eveniet architecto", SortBy = "Popular"},
                new Post { Id = 2, UserId = 1, Title = "qui est esse", Body = "est rerum tempore vitae sequi sint nihil reprehenderit dolor beatae ea dolores neque fugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis qui aperiam non debitis possimus qui neque nisi nulla", SortBy = "Popular"},
                new Post { Id = 3, UserId = 1, Title = "ea molestias quasi exercitationem repellat qui ipsa sit aut", Body = "et iusto sed quo iurevoluptatem occaecati omnis eligendi aut ad voluptatem doloribus vel accusantium quis pariatur molestiae porro eius odio et labore et velit aut", SortBy = "Popular"},
                new Post { Id = 4, UserId = 1, Title = "eum et est occaecati", Body = "ullam et saepe reiciendis voluptatem adipiscisit amet autem assumenda provident rerum culpaquis hic commodi nesciunt rem tenetur doloremque ipsam iure quis sunt voluptatem rerum illo velit", SortBy = "Trending"},
                new Post { Id = 5, UserId = 1, Title = "nesciunt quas odio", Body = "repudiandae veniam quaerat sunt sednalias aut fugiat sit autem sed est nvoluptatem omnis possimus esse voluptatibus quis nest aut tenetur dolor neque", SortBy = "Trending"},
                new Post { Id = 6, UserId = 1, Title = "dolorem eum magni eos aperiam quia", Body = "ut aspernatur corporis harum nihil quis provident sequimollitia nobis aliquid molestiaeperspiciatis et ea nemo ab reprehenderit accusantium quasvoluptate dolores velit et doloremque molestiae", SortBy = "New"},
                new Post { Id = 7, UserId = 1, Title = "magnam facilis autem", Body = "dolore placeat quibusdam ea quo vitae magni quis enim qui quis quo nemo aut saepequidem repellat excepturi ut quiasunt ut sequi eos ea sed quas", SortBy = "New"},
                new Post { Id = 8, UserId = 1, Title = "dolorem dolore est ipsam", Body = "dignissimos aperiam dolorem qui eum facilis quibusdam animi sint suscipit qui sint possimus cumquaerat magni maiores excepturiipsam ut commodi dolor voluptatum modi aut vitae", SortBy = "New"},
                new Post { Id = 9, UserId = 1, Title = "nesciunt iure omnis dolorem tempora et accusantium", Body = "consectetur animi nesciunt iure doloreenim quia adveniam autem ut quam aut nobiset est aut quod aut provident voluptas autem voluptas", SortBy = "Popular"}
            };
        }
        public async Task<Post> CreatePost(Post post)
        {
            try
            {
                int maxid = _posts.Max(x => x.Id) + 1;
                post.Id = maxid;
                Post NewPost = await Task.Run(() => {
                    _posts.Add(post);
                    return post;
                });
                return NewPost;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void DeletePost(int Id)
        {
            var post = _posts.FirstOrDefault(x => x.Id == Id);
            if (post != null)
            {
                _posts.Remove(post);
            }
        }

        public async Task<List<Post>> GetAllPost()
        {
            List<Post> list = await Task.Run(() => _posts);
            return list;
        }
        public async Task<List<Post>> GetAllPostSortBy(string Sortby)
        {
            List<Post> list = await Task.Run(() => _posts.Where(x=> x.SortBy == Sortby).ToList());
            return list;
        }
        public async Task<Post> GetPostById(int Id)
        {
            Post post = await Task.Run(() => _posts.Where(x => x.Id == Id).FirstOrDefault());
            return post;
        }
        public async Task<Post> UpdatePost(Post post)
        {
            try
            {
                Post NewPost = await Task.Run(() => {
                    var _Post = _posts.FirstOrDefault(x => x.Id == post.Id);
                    if (_Post != null)
                    {
                        _Post.Title = post.Title;
                        _Post.Body = post.Body;
                        _Post.SortBy = post.SortBy;
                        return post;
                    }
                    else
                    {
                        return null;
                    }
                    
                });
                return NewPost;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            
        }
    }
}
