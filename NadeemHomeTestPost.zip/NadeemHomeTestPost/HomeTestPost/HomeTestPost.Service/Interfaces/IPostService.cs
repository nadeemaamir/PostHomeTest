﻿using HomeTestPost.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeTestPost.Service.Interfaces
{
    public interface IPostService 
    {
        Task<Post> CreatePost(Post post);
        void DeletePost(int Id);
        Task<Post> GetPostById(int Id);
        Task<Post> UpdatePost(Post post);
        Task<List<Post>> GetAllPost();
        Task<List<Post>> GetAllPostSortBy(string Sortby);
    }



}
