import Post from '../src/Pages/Post';
import Navbar from '../src/Components/Navbar'
import UserContext from './UserContext';

const user = {
  name: 'Nadeem Aamir'
}
function App() {
  return (
    <UserContext.Provider value={user}>
      <Navbar />
      <Post />
    </UserContext.Provider>
  );
}

export default App;
