import { useEffect, useCallback, useState } from "react";
import axios from 'axios';
import Endpoints from '../APIUrls/endpoints';
import Post from '../Components/Post'
import swal from "sweetalert";

const Posts = () => {
    const [posts, setPosts] = useState([]);
    const [title, setTitle] = useState('');
    const [body, SetBody] = useState('');


    const getAllPost = useCallback(() => {
        axios.get(Endpoints.GETALLPOSTS)
            .then(response => {
                setPosts(response.data);
            })
            .catch(error => {
                console.log(error);
            });
    });
    const HandlePost = (e) => {
        e.preventDefault();
        axios.post(Endpoints.CREATEPOST, { usertd: 1, title: title, body: body, sortBy: "New" }).then(
            res => {
                getAllPost();
                swal("Success!", "Data has been saved successfully!", "success");
            }
        )
    }

    useEffect(() => {
        getAllPost();
    }, []);

    return (

        <div className='container'>
            <div className='row'>
                <div className='col-12'>
                    <form onSubmit={HandlePost}>
                        <div className="mb-3">
                            <label className="form-label">Title</label>
                            <input type="Text" class="form-control" value={title} id="exampleFormControlInput1" onChange={e => setTitle(e.target.value)} />
                        </div>
                        <div className="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Post</label>
                            <textarea class="form-control" value={body} id="exampleFormControlTextarea1" rows="3" onChange={e => SetBody(e.target.value)}></textarea>
                        </div>
                        <div className="mb-3">
                            <button type="sbumit" class="btn btn-info">Post</button>
                        </div>
                    </form>
                </div>
            </div>
            <h1 className='text-center'>Posts</h1>
            <div className='row'>
                {
                    posts.slice(0, 30).map(item => <Post data={item} />)
                }
            </div>
        </div >
    );
};

export default Posts;
