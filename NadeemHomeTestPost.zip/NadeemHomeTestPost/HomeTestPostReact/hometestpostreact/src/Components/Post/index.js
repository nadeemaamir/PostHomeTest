import React from 'react';
import { Link } from 'react-router-dom'

const Post = (props) => {

    const { title, body, sortBy } = props.data;
    return (
        <div className='col-sm-12'>
            <div className="card">
                <div className="card-body">

                    {sortBy === "New" &&
                        <span class="badge rounded-pill bg-primary">{sortBy}</span>
                    }
                    {sortBy === "Trending" &&
                        <span class="badge rounded-pill bg-danger">{sortBy}</span>
                    }{sortBy === "Popular" &&
                        <span class="badge rounded-pill bg-warning">{sortBy}</span>
                    }

                    <h5 className="card-title">{title}</h5>
                    <p className="card-text">{body}</p>
                </div>
                <div className="card-body">
                    <a href="#" className="card-link">Edit</a>
                    <a href="#" className="card-link">Like</a>
                    <a href="#" className="card-link">Comment</a>
                </div>
            </div>
        </div>

    );
}
export default Post;