const Endpoints = {
    GETALLPOSTS: 'http://localhost:59028/api/post/getallposts',
    GETALLPOSTSBYSTATUS: 'http://localhost:59028/api/post/getallposts/',
    CREATEPOST: 'http://localhost:59028/api/post/createpost',
    UPDATEPOST: 'http://localhost:59028/api/post/updatepost',
    DELETEPOST: 'http://localhost:59028/api/post/deletepost',
    GETPOSTBYID: 'http://localhost:59028/api/post/getpostbyid',
}
export default Endpoints;